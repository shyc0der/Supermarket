package com.example.sign;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.sign.Common.common;
import com.example.sign.Model.Order;
import com.example.sign.Model.Request;
import com.example.sign.ViewHolder.orderViewholder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class orderView extends AppCompatActivity {
RecyclerView recyclerV;
FirebaseDatabase firebaseDatabase;
    private FirebaseAuth mAuth;
DatabaseReference databaseReference;
FirebaseRecyclerAdapter<Request, orderViewholder> requests;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_view);
        mAuth = FirebaseAuth.getInstance();
        recyclerV=findViewById(R.id.order_recycle);
        firebaseDatabase=FirebaseDatabase.getInstance();
        String Uid=mAuth.getUid();
        databaseReference=firebaseDatabase.getReference("Orders");
        recyclerV.setHasFixedSize(true);
        recyclerV.setLayoutManager(new LinearLayoutManager(this));
        String email1 = mAuth.getCurrentUser().getEmail();


loadOrders(email1);

    }

    private void loadOrders(String email) {
        String Uid=mAuth.getCurrentUser().getUid();
        requests=new FirebaseRecyclerAdapter<Request,orderViewholder>
                ( Request.class,
                        R.layout.productcart,
                        orderViewholder.class,
                        databaseReference.orderByChild("email").equalTo(email)) {
            @Override
            protected void populateViewHolder(orderViewholder viewHolder, Request model, int position) {
                viewHolder.address6.setText(model.getAddress());
                viewHolder.status6.setText(convertCodeToStatus(model.getStatus()));
                viewHolder.phone6.setText(model.getEmail());
                viewHolder.orderid6.setText(requests.getRef(position).getKey());
            }
        };
recyclerV.setAdapter(requests);
    }

    private String convertCodeToStatus(String status) {
        if (status.equals("0"))
        {
            return "Placed";
        }
        else if (status.equals("1"))
            return  "0n my way";
        else
            return  "shipped";
    }
}
