package com.example.sign.ViewHolder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sign.Interface.ItemClickListener;
import com.example.sign.R;

public class orderViewholder  extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView orderid6,status6,phone6,address6;

   private ItemClickListener clickListener;

    public orderViewholder(@NonNull View itemView) {
        super(itemView);
       orderid6=itemView.findViewById(R.id.order_Id);
       status6=itemView.findViewById(R.id.order_status);
       phone6=itemView.findViewById(R.id.order_email);
       address6=itemView.findViewById(R.id.order_address);

        itemView.setOnClickListener(this);

    }

    public orderViewholder(@NonNull View itemView, ItemClickListener clickListener) {
        super(itemView);

        this.clickListener = clickListener;
    }

    @Override
    public void onClick(View v) {
        clickListener.onClick(v,getAdapterPosition(),false);


    }
}
